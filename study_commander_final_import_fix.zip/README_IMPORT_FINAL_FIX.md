# Final Import Fix

هذا الباتش يصلح خطأ:

`ImportError: cannot import name 'seconds_until_next_prayer_for_user' from 'app.services.prayer'`

## الملفات المطلوبة
استبدل فقط:

- `app/services/prayer.py`
- `app/models.py`

ثم اعمل Commit و Redeploy على Railway.

## ماذا أصلح؟
- أضاف الدالة `seconds_until_next_prayer_for_user` التي يحتاجها البومودورو.
- أضاف جدول `PrayerManualTime` لحفظ أوقات الصلاة اليدوية.
- أبقى التذكير والبومودورو يستخدمان التوقيت اليدوي إذا موجود، وإلا يرجع لتوقيت حقيبة المؤمن/التلقائي.
